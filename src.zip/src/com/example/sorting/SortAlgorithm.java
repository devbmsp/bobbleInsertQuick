package com.example.sorting;

public interface SortAlgorithm {
    void sort(int[] array);
    String getName();
}
